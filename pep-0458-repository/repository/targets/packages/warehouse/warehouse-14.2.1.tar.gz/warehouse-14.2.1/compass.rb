http_path = "/"

css_dir = "warehouse/static/warehouse/css"
sass_dir = "warehouse/static/warehouse/sass"
images_dir = "warehouse/static/warehouse/images"
javascripts_dir = "warehouse/static/warehouse/js"
fonts_dir = "warehouse/static/warehouse/fonts"

# Output options.
relative_assets = true
line_comments = false
output_style = :compact
