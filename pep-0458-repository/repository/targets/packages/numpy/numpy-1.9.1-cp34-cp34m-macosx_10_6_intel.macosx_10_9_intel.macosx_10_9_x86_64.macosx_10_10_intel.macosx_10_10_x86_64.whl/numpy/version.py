
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.9.1'
version = '1.9.1'
full_version = '1.9.1'
git_revision = 'd44b9c61499f8bc5a9fc94286cd52f05e15e003f'
release = True

if not release:
    version = full_version
