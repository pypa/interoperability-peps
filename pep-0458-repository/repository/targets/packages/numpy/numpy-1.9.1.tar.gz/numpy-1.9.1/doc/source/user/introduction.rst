************
Introduction
************


.. toctree::

   whatisnumpy
   install
   howtofind
