.. scipy-sphinx-theme documentation master file, created by
   sphinx-quickstart on Sun Apr 21 11:22:24 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to scipy-sphinx-theme's documentation!
==============================================

The theme is under `_theme`, this document contains various test
pages.

Contents:

.. toctree::
   :maxdepth: 2

   README
   test_optimize
   test_autodoc
   test_autodoc_2
   test_autodoc_3
   test_autodoc_4

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

